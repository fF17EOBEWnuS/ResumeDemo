#!/bin/sh
sudo apt update
sudo apt install -y shadowsocks-libev
sudo apt-get install -y --no-install-recommends build-essential autoconf libtool libssl-dev libpcre3-dev libev-dev asciidoc xmlto automake


PAYLOAD_LINE=`awk '/^__PAYLOAD_BELOW__/ {print NR + 1; exit 0; }' $0`

tail -n+$PAYLOAD_LINE $0 | tar xzv -C /home/ubuntu/ 

#git clone https://github.com/shadowsocks/simple-obfs.git
cd /home/ubuntu/files/simple-obfs
#git submodule update --init --recursive
./autogen.sh
./configure && make
sudo make install

sudo systemctl stop shadowsocks-libev
sudo systemctl disable shadowsocks-libev

sudo /usr/bin/ss-server -c /home/ubuntu/files/default.json -f /home/ubuntu/files/default.pid -u 

exit 0

__PAYLOAD_BELOW__
